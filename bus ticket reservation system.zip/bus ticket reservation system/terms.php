<?php include"inc/header.php" ; ?>
</head>
<?php include("inc/header_bottom.php"); ?>
<!--- /footer-btm ---->
<!--- banner-1 ---->
<div class="banner-1 ">
	<div class="container" >
		<h1 style="color: black;"> Terms of service </h1>
	</div>
</div>
<!-- /banner-1 -->
<!--- privacy -->
<div class="privacy">
<!--728x90-->
	<div class="container" style="text-align: justify;">
	<h3>This page is cooming soon... </h3>
		<p>our website is an online ticketing service. We do not operate any buslines of our own.</p>


	</div>
</div>
