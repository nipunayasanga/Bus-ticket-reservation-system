<?php include"inc/header.php";?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Staatliches&display=swap');
</style>

<?php
	$AllCity = $city->GetAllCityByUniqueName();
	$AllCity = mysqli_fetch_all($AllCity,MYSQLI_ASSOC);
?>


<style>
body, html {
  height: 100%;
  margin: 0;
}

body, html {
  /* The image used */
  background-image: url("images/home.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>

</head>
<?php include("inc/header_bottom.php"); ?>

<!--- banner ---->


<!---728x90-->
<div >
	<div class="col-md-1 bann-info1" >
		
	</div>
	<div class="copy-right" style=" position:fixed; width:100%; height:200px;">
	<div class="container">
	
		
		<p style="height: 90px; padding-top:25px;"></p>
	</div>
</div>
	<div class="col-md-9 bann-info">
		<h1 style="color:white;  font-family: 'Anton', sans-serif; "><span style="color:#e00c11; font-size:80px">AM travels </span></h1>
<div>
	<h1 style="color:white; font-family: 'Josefin Sans', sans-serif;">Online Bus Ticket Reservation</h1>
</div>
	</div>
	<div class="clearfix"></div>
</div>


<!--- /routes -->
 <?php include"inc/footer.php" ; ?>