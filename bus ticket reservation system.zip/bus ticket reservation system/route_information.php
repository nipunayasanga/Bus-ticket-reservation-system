<?php include"inc/header.php" ; ?>
</head>
<?php include("inc/header_bottom.php"); ?>
<!--- /footer-btm ---->
<!--- banner-1 ---->
<div class="banner-1 ">
	<div class="container" style="margin-top: 100px" >
  
    <!DOCTYPE html>
<html>
<head>
<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 1000px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>
<body>

<div class="gallery" style="padding-bottom: 40px;">
  <a target="_blank" href="img_5terre.jpg">
    <img src="images/01.png" alt="Cinque Terre" width="1000" height="1000">
  </a>
  <div class="desc">Colombo to Hambantota</div>
</div>

<div class="gallery">
  <a target="_blank" href="img_forest.jpg">
    <img src="images/02.png" alt="Forest" width="600" height="400">
  </a>
  <div class="desc">Colombo to Batticaloa</div>
</div>

<div class="gallery">
  <a target="_blank" href="img_lights.jpg">
    <img src="images/03.png" alt="Northern Lights" width="600" height="400">
  </a>
  <div class="desc">Colombo to Matara</div>
</div>



</body>
</html>



</div>

</body>

