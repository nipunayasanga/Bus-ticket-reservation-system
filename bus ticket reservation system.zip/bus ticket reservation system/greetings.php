<?php include"inc/header.php" ; ?>
</head>
<?php include("inc/header_bottom.php"); ?>

<!--- /footer-btm -->
<!--- banner-1 -->
<div class="banner-1 ">
	<div class="container">
		<h1 style="color: black"> Enjoy Your Journey </h1>
	</div>
</div>
<!--- /banner-1 -->

<!--- agent -->
<div class="agent">
<!---728x90-->
	<div class="container">
	
	<div class="col-md-7 " >
	 <div>
	    <p> <h3 style="font-weight: bolder; color:#001a00">Hi, <b style="color:red"><?php echo Session::get("passenger_name");?>!</b> Thank you for your booking!  </h3></p>
	    <p> <h4>Your REF Number is: <b style="color:red"><?php echo Session::get("ref_no");?></b> </h4></p>
	    <p style="color:#001a00; text-align: justify;">We must varifing your information, we will send you a confirmation email.Then,you will be able to print your Busticket. </p>
	    <p style="color:#001a00">Thank you for choosing AM travel service!</p>		   
	 </div>	
	</div>
	
		
	<aside id="journey" class="col-md-4 paside agent-right">

              <div class="page_title" style="margin-right:2%;">
                  <h3>Your Trip Details</h3>
              </div><br>
			  
			  
			  

              <ul style="margin-left:2%;">
              	 <?php 
              		$Available_bus=$trip_info->GetSearchBusBytripId(intval($_GET['trip_id']));
              		if($Available_bus)
					{
						$data = $Available_bus->fetch_assoc();

              	 ?>

                  <!--//// For Eid  /////-->
                  <li><b style="font-weight:bolder;">Journey:</b> <?php echo Session::get("from_city"); ?> - <?php echo Session::get("to_city"); ?> </li>
                  <!--//// For Eid  /////-->
                  <li><b style="font-weight:bolder;">Bus No: </b><?php echo $data['bus_no']; ?></li>
                  <li><b style="font-weight:bolder;">Date of Journey:</b> <?php echo date('F j, Y', strtotime(Session::get("journey_date")));?></li>
                  <li><b style="font-weight:bolder;">Starting Time:</b> <?php echo date('h:i A', strtotime($data['departure_time'])); ?></li> 
                  <li><b style="font-weight:bolder;">Seat No(s):</b> <span> <?php echo implode(',', $_SESSION['seats']);  ?></span></li>
                  <li><b style="font-weight:bolder;">Ticket Price Per Seat: </b> <span><?php echo $data['fare'];?> Rs</span></li>
                  <li><b style="font-weight:bolder;">Total Trip Price: </b> <span><?php echo Session::get("total_amount");?> Rs</span></li>
                  <?php } ?>
              
            </ul>

    </aside>
						
	
		<div class="clearfix"></div>
	
		 
		
			
		 
	</div>
	
	<!--728x90-->
</div>
<!-- /agent -->

<!--- footer-top -->
