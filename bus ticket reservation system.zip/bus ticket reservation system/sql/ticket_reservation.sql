-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2021 at 02:43 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_info`
--

CREATE TABLE `tbl_admin_info` (
  `admin_id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `img_url` varchar(40) NOT NULL,
  `activation_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin_info`
--

INSERT INTO `tbl_admin_info` (`admin_id`, `name`, `email`, `phone_number`, `address`, `password`, `img_url`, `activation_status`) VALUES
(32, 'amitha eshan', 'amithaeshan96@gmail.com', '0750482555', '14/no.colony hambantota', '698d51a19d8a121ce581499d7b701668', 'agent_img/6dc246ec5a.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agent_info`
--

CREATE TABLE `tbl_agent_info` (
  `agent_id` int(11) NOT NULL,
  `counter_id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(33) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `img_url` varchar(40) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_agent_info`
--

INSERT INTO `tbl_agent_info` (`agent_id`, `counter_id`, `name`, `email`, `phone_number`, `address`, `password`, `img_url`, `active_status`) VALUES
(1, 1, 'chinthaka', 'chinthaka@gmail.com', '0712418222', '14/no.kalawewa anuradapura', 'd9b1d7db4cd6e70935368a1efb10e377', 'agent_img/23afd3910e.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booked_seats`
--

CREATE TABLE `tbl_booked_seats` (
  `id` int(11) NOT NULL,
  `ref_no` int(40) NOT NULL,
  `trip_id` int(40) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `seat_no` varchar(5) NOT NULL,
  `date` date NOT NULL,
  `seat_status` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_booked_seats`
--

INSERT INTO `tbl_booked_seats` (`id`, `ref_no`, `trip_id`, `passenger_id`, `seat_no`, `date`, `seat_status`) VALUES
(180, 6315, 2, 15, 'B1', '2021-01-05', 0),
(181, 6315, 2, 15, 'A1', '2021-01-05', 0),
(182, 6315, 2, 15, 'A2', '2021-01-05', 0),
(183, 6315, 2, 15, 'B2', '2021-01-05', 0),
(184, 6315, 2, 15, 'B3', '2021-01-05', 0),
(185, 6607, 13, 16, 'B1', '2021-01-05', 1),
(186, 6607, 13, 16, 'A2', '2021-01-05', 1),
(187, 6607, 13, 16, 'A4', '2021-01-05', 1),
(188, 6607, 13, 16, 'A3', '2021-01-05', 1),
(189, 6607, 13, 16, 'A1', '2021-01-05', 1),
(190, 1501, 3, 15, 'B3', '2021-01-05', 0),
(191, 1501, 3, 15, 'C3', '2021-01-05', 0),
(192, 1501, 3, 15, 'D3', '2021-01-05', 0),
(193, 1501, 3, 15, 'E3', '2021-01-05', 0),
(194, 1501, 3, 15, 'F3', '2021-01-05', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking_info`
--

CREATE TABLE `tbl_booking_info` (
  `booking_id` int(40) NOT NULL,
  `ref_no` int(40) NOT NULL,
  `trip_id` int(40) NOT NULL,
  `counter_id` int(40) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `reference_no` varchar(60) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `journey_date` date NOT NULL,
  `booking_date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `booking_status` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_booking_info`
--

INSERT INTO `tbl_booking_info` (`booking_id`, `ref_no`, `trip_id`, `counter_id`, `passenger_id`, `reference_no`, `total_amount`, `journey_date`, `booking_date`, `booking_status`) VALUES
(35, 6315, 2, 1, 15, '00', 4000, '2021-01-05', '2021-01-03 18:32:35', 0),
(36, 6607, 13, 1, 16, '00', 2500, '2021-01-05', '2021-01-04 13:34:42', 1),
(37, 1501, 3, 1, 15, '00', 3500, '2021-01-05', '2021-01-04 12:56:42', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bus_info`
--

CREATE TABLE `tbl_bus_info` (
  `bus_id` int(11) NOT NULL,
  `bus_no` varchar(11) NOT NULL,
  `bus_type` char(20) NOT NULL,
  `img_bus` varchar(40) NOT NULL,
  `no_of_seats` int(11) NOT NULL DEFAULT 40
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_bus_info`
--

INSERT INTO `tbl_bus_info` (`bus_id`, `bus_no`, `bus_type`, `img_bus`, `no_of_seats`) VALUES
(2, 'dam rajini', 'A/C Sleeper', 'img/71e81c37ff.jpg', 40),
(3, 'dumburu lam', 'Non A/C', 'img/70eb3ba9b3.jpg', 40),
(4, 'new line', 'Non A/C', 'img/bca8ee7c87.jpg', 40);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cancel_request`
--

CREATE TABLE `tbl_cancel_request` (
  `request_id` int(11) NOT NULL,
  `ref_no` int(40) NOT NULL,
  `counter_id` int(40) NOT NULL,
  `easycash_no` varchar(15) NOT NULL,
  `cancel_status` int(15) NOT NULL DEFAULT 0,
  `cancel_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cancel_request`
--

INSERT INTO `tbl_cancel_request` (`request_id`, `ref_no`, `counter_id`, `easycash_no`, `cancel_status`, `cancel_date`) VALUES
(7, 28046, 2, '01738868597', 0, '2018-04-06 21:03:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cities`
--

CREATE TABLE `tbl_cities` (
  `city_id` int(40) NOT NULL,
  `city_name` char(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cities`
--

INSERT INTO `tbl_cities` (`city_id`, `city_name`) VALUES
(70, 'colombo'),
(71, 'Batticaloa'),
(72, 'Hambantota'),
(73, 'Matara');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter_info`
--

CREATE TABLE `tbl_counter_info` (
  `counter_id` int(40) NOT NULL,
  `city_name` char(40) NOT NULL,
  `counter_name` char(50) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `location_counter` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_counter_info`
--

INSERT INTO `tbl_counter_info` (`counter_id`, `city_name`, `counter_name`, `contact_no`, `location_counter`) VALUES
(1, 'colombo', 'pettah Bus Stand', '0754598965 ', 'pettah, colombo'),
(2, 'Batticaloa', 'batticaloa bus stand', '0754598965', '1st row ,main street batticaloa .'),
(3, 'Hambantota', 'Hambantota Bus Point', '0754598965', 'Kurilam Road, Hambantota'),
(4, 'Matara', 'Matara Bus Poin', '0745485478', 'Matara road, katunayake');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_passenger_info`
--

CREATE TABLE `tbl_passenger_info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_passenger_info`
--

INSERT INTO `tbl_passenger_info` (`id`, `name`, `address`, `email`, `mobile`, `password`) VALUES
(9, 'sanju', '145/d/1/walawwaththa,watinapaha', 'pipuni@gmail.com', '0712418222', '202cb962ac59075b964b07152d234b70'),
(10, 'sanda', '14/no.walasmulla,deniyaya', 'vihagi50perera@gmail.com', '0750544952', '202cb962ac59075b964b07152d234b70'),
(11, 'pipuni', 'no.5 minuwangoda', 'info@gmail.com', '0758211458', '202cb962ac59075b964b07152d234b70'),
(12, 'chinthaka nadun', 'aaaaaaaaaaaaa', 'njgihan@gmail.com', '0750844256', '202cb962ac59075b964b07152d234b70'),
(7, 'nipuna yasanga', '145/d/1/walawwaththa,watinapaha', 'nipunayes@gmail.com', '0712418222', '202cb962ac59075b964b07152d234b70'),
(8, 'nipuna yasanga', '145/d/1/walawwaththa,watinapaha', 'nipunayaka@gmail.com', '0712418222', '202cb962ac59075b964b07152d234b70'),
(13, 'kethaki', 'no.15,highlevel road,nugegoda', 'kethaki@gmail.com', '0762544856', '202cb962ac59075b964b07152d234b70'),
(14, 'vihagiperera', '14/no.walasmulla,deniyaya', 'sandaminiasanka52@gmal.com', '0712418222', '202cb962ac59075b964b07152d234b70'),
(15, 'amitha eshan', 'no.02, colaniya hambantota', 'amithaeshan96@gmail.com', '0715485222', '698d51a19d8a121ce581499d7b701668'),
(16, 'sanju', 'no.5 ampara', 'sanjusandaruwan@gmail.com', '0750866523', '698d51a19d8a121ce581499d7b701668');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reserved_seat`
--

CREATE TABLE `tbl_reserved_seat` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `booked_time` datetime NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL,
  `seat_no` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reserved_seat`
--

INSERT INTO `tbl_reserved_seat` (`id`, `trip_id`, `user_id`, `session_id`, `bus_id`, `booked_time`, `date`, `seat_no`) VALUES
(1359, 5, 5, 'dttc5l1m9d3j9ac4gih21nab82', 1, '2018-04-06 21:54:49', '2018-04-11', 'I2'),
(1524, 13, 12, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 10:10:06', '2021-01-03', 'I3'),
(1522, 2, 12, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 10:07:31', '2021-01-03', 'E2'),
(1523, 2, 12, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 10:07:32', '2021-01-03', 'F2'),
(1521, 2, 12, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 10:07:31', '2021-01-03', 'D2'),
(1520, 2, 12, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 10:07:30', '2021-01-03', 'C2'),
(1519, 2, 12, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 10:07:30', '2021-01-03', 'B2'),
(1509, 14, 9, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-02 20:16:57', '2021-01-03', 'F3'),
(1508, 14, 9, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-02 20:16:56', '2021-01-03', 'G3'),
(1503, 3, 7, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-02 20:06:18', '0000-00-00', 'E3'),
(1504, 3, 7, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-02 20:06:19', '0000-00-00', 'F3'),
(1505, 14, 9, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-02 20:16:55', '2021-01-03', 'J3'),
(1506, 14, 9, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-02 20:16:56', '2021-01-03', 'I3'),
(1507, 14, 9, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-02 20:16:56', '2021-01-03', 'H3'),
(1501, 3, 7, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-02 20:06:17', '0000-00-00', 'C3'),
(1500, 3, 7, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-02 20:06:16', '0000-00-00', 'B3'),
(1502, 3, 7, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-02 20:06:18', '0000-00-00', 'D3'),
(1498, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 19:59:12', '2021-01-02', 'E3'),
(1488, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 16:38:52', '2021-01-03', 'B1'),
(1497, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 19:59:12', '2021-01-02', 'D3'),
(1496, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 19:59:11', '2021-01-02', 'C3'),
(1495, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 19:59:11', '2021-01-02', 'B3'),
(1494, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 19:59:11', '2021-01-02', 'A3'),
(1486, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 16:38:47', '2021-01-03', 'A4'),
(1485, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 16:38:47', '2021-01-03', 'A3'),
(1484, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 16:38:46', '2021-01-03', 'A2'),
(1483, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-02 16:38:45', '2021-01-03', 'A1'),
(1525, 13, 12, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 10:10:06', '2021-01-03', 'H3'),
(1526, 13, 12, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 10:10:07', '2021-01-03', 'F3'),
(1527, 13, 12, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 10:10:07', '2021-01-03', 'E3'),
(1528, 13, 12, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 10:10:08', '2021-01-03', 'D3'),
(1529, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 13:39:33', '0000-00-00', 'J3'),
(1530, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 13:39:33', '0000-00-00', 'I3'),
(1531, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 13:39:34', '0000-00-00', 'H3'),
(1532, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 13:39:34', '0000-00-00', 'G3'),
(1533, 2, 7, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 13:39:34', '0000-00-00', 'F3'),
(1534, 13, 13, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 14:26:06', '2021-01-04', 'A1'),
(1535, 13, 13, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 14:26:07', '2021-01-04', 'A2'),
(1536, 13, 13, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 14:26:07', '2021-01-04', 'A3'),
(1537, 13, 13, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 14:26:08', '2021-01-04', 'A4'),
(1538, 13, 13, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-03 14:26:09', '2021-01-04', 'B1'),
(1542, 2, 10, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 17:37:29', '2021-01-04', 'B3'),
(1541, 2, 10, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 17:37:28', '2021-01-04', 'A3'),
(1543, 2, 10, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 17:37:29', '2021-01-04', 'D3'),
(1544, 2, 10, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 17:37:30', '2021-01-04', 'C3'),
(1545, 2, 10, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 17:37:32', '2021-01-04', 'E3'),
(1546, 2, 10, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-03 17:52:17', '0000-00-00', 'F2'),
(1547, 3, 14, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-03 17:56:37', '2021-01-04', 'A1'),
(1548, 3, 14, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-03 17:56:37', '2021-01-04', 'A2'),
(1549, 3, 14, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-03 17:56:38', '2021-01-04', 'A3'),
(1550, 3, 14, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-03 17:56:38', '2021-01-04', 'A4'),
(1551, 3, 14, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-03 17:56:39', '2021-01-04', 'B1'),
(1552, 2, 15, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-04 00:02:16', '2021-01-05', 'B1'),
(1553, 2, 15, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-04 00:02:17', '2021-01-05', 'A1'),
(1554, 2, 15, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-04 00:02:18', '2021-01-05', 'A2'),
(1555, 2, 15, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-04 00:02:18', '2021-01-05', 'B2'),
(1556, 2, 15, 'quvidf4a1lrg0bskgsofs0euli', 2, '2021-01-04 00:02:20', '2021-01-05', 'B3'),
(1566, 13, 16, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-04 14:44:59', '2021-01-05', 'B1'),
(1565, 13, 16, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-04 14:44:59', '2021-01-05', 'A2'),
(1564, 13, 16, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-04 14:44:58', '2021-01-05', 'A4'),
(1563, 13, 16, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-04 14:44:58', '2021-01-05', 'A3'),
(1562, 13, 16, 'quvidf4a1lrg0bskgsofs0euli', 4, '2021-01-04 14:44:57', '2021-01-05', 'A1'),
(1567, 3, 15, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-04 18:26:12', '2021-01-05', 'B3'),
(1568, 3, 15, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-04 18:26:12', '2021-01-05', 'C3'),
(1569, 3, 15, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-04 18:26:13', '2021-01-05', 'D3'),
(1570, 3, 15, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-04 18:26:13', '2021-01-05', 'E3'),
(1571, 3, 15, 'quvidf4a1lrg0bskgsofs0euli', 3, '2021-01-04 18:26:14', '2021-01-05', 'F3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trip_info`
--

CREATE TABLE `tbl_trip_info` (
  `trip_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `from_city` char(40) NOT NULL,
  `to_city` char(40) NOT NULL,
  `fare` varchar(40) NOT NULL,
  `departure_time` varchar(12) NOT NULL,
  `arrival_time` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_trip_info`
--

INSERT INTO `tbl_trip_info` (`trip_id`, `bus_id`, `from_city`, `to_city`, `fare`, `departure_time`, `arrival_time`) VALUES
(2, 2, 'colombo', 'Batticaloa', '800', '14:46', '04:51'),
(3, 3, 'colombo', 'Hambantota', '700', '17:46', '05:46'),
(13, 4, 'colombo', 'Matara', '500', '14:46', '04:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_info`
--
ALTER TABLE `tbl_admin_info`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_agent_info`
--
ALTER TABLE `tbl_agent_info`
  ADD PRIMARY KEY (`agent_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_booked_seats`
--
ALTER TABLE `tbl_booked_seats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_booking_info`
--
ALTER TABLE `tbl_booking_info`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `tbl_bus_info`
--
ALTER TABLE `tbl_bus_info`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `tbl_cancel_request`
--
ALTER TABLE `tbl_cancel_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `tbl_cities`
--
ALTER TABLE `tbl_cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `tbl_counter_info`
--
ALTER TABLE `tbl_counter_info`
  ADD PRIMARY KEY (`counter_id`);

--
-- Indexes for table `tbl_passenger_info`
--
ALTER TABLE `tbl_passenger_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reserved_seat`
--
ALTER TABLE `tbl_reserved_seat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_trip_info`
--
ALTER TABLE `tbl_trip_info`
  ADD PRIMARY KEY (`trip_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_info`
--
ALTER TABLE `tbl_admin_info`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_agent_info`
--
ALTER TABLE `tbl_agent_info`
  MODIFY `agent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_booked_seats`
--
ALTER TABLE `tbl_booked_seats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

--
-- AUTO_INCREMENT for table `tbl_booking_info`
--
ALTER TABLE `tbl_booking_info`
  MODIFY `booking_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_bus_info`
--
ALTER TABLE `tbl_bus_info`
  MODIFY `bus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_cancel_request`
--
ALTER TABLE `tbl_cancel_request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_cities`
--
ALTER TABLE `tbl_cities`
  MODIFY `city_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `tbl_counter_info`
--
ALTER TABLE `tbl_counter_info`
  MODIFY `counter_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_passenger_info`
--
ALTER TABLE `tbl_passenger_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_reserved_seat`
--
ALTER TABLE `tbl_reserved_seat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1572;

--
-- AUTO_INCREMENT for table `tbl_trip_info`
--
ALTER TABLE `tbl_trip_info`
  MODIFY `trip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
