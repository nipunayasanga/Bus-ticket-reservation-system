
Login Credentials

    Admin:
    username: amithaeshan96@gmail.com
    usertype: admin
    password: 111
    
    User:
    email: sanjusandaruwan@gmail.com
    password: 111

